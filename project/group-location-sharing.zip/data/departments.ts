export const departments = [
  "General Surgery",
  "Orthopedics",
  "Cardiology",
  "Neurology",
  "Oncology",
  "Gynecology",
  "ENT",
  "Urology",
  "Gastroenterology",
  "Pulmonology",
  "Ophthalmology",
  "Dermatology",
]
