export const siteConfig = {
  name: "HarmonyCare Hospital Management",
  nameShort: "HarmonyCare",
  description:
    "Comprehensive hospital information on doctors, surgeries, and facilities with transparent pricing and details.",
}
