export type Surgery = {
  slug: string
  name: string
  department: string
  summary: string
  description: string
  durationHours: number
  preparation: string[]
  risks: string[]
  recoveryTime: string
  basePrice: number
  surgeonFeeRange: [number, number]
  anesthesiaFee: number
  facilityFee: number
  roomChargesPerDay: number
}

export const surgeries: Surgery[] = [
  {
    slug: "appendectomy",
    name: "Appendectomy",
    department: "General Surgery",
    summary: "Removal of an inflamed or infected appendix to prevent rupture.",
    description:
      "Appendectomy is performed to treat appendicitis. The procedure can be laparoscopic or open depending on clinical assessment.",
    durationHours: 1.5,
    preparation: [
      "Fasting for 8 hours prior unless emergency",
      "Pre-operative blood work and imaging",
      "Consent and anesthesia evaluation",
    ],
    risks: ["Bleeding", "Infection", "Anesthesia risks", "Adjacent organ injury"],
    recoveryTime: "2-4 weeks for full recovery; light activity after 1 week.",
    basePrice: 3500,
    surgeonFeeRange: [800, 1500],
    anesthesiaFee: 600,
    facilityFee: 900,
    roomChargesPerDay: 400,
  },
  {
    slug: "total-knee-replacement",
    name: "Total Knee Replacement",
    department: "Orthopedics",
    summary: "Replacement of knee joint surfaces to reduce pain and improve mobility.",
    description:
      "A TKR replaces damaged joint surfaces with prosthetic components. Rehabilitation begins soon after surgery.",
    durationHours: 2.5,
    preparation: ["Medical clearance and imaging", "Fasting as advised", "Prehab exercises and home safety planning"],
    risks: ["Blood clots", "Infection", "Stiffness", "Implant loosening"],
    recoveryTime:
      "Hospital stay 2-3 days. Walking with support in 1-2 days. Full recovery typically within 3-6 months.",
    basePrice: 16500,
    surgeonFeeRange: [3000, 4500],
    anesthesiaFee: 1500,
    facilityFee: 2800,
    roomChargesPerDay: 600,
  },
  {
    slug: "cataract-surgery",
    name: "Cataract Surgery",
    department: "Ophthalmology",
    summary: "Removal of cloudy lens and insertion of artificial intraocular lens.",
    description:
      "Performed under local anesthesia, cataract surgery is typically outpatient with rapid visual recovery.",
    durationHours: 0.75,
    preparation: ["Pre-op eye measurements", "Topical antibiotics as advised", "Arrange transport post-procedure"],
    risks: ["Infection", "Inflammation", "Lens dislocation", "Retinal detachment (rare)"],
    recoveryTime: "Most patients resume normal activities within a few days; full healing in 4-6 weeks.",
    basePrice: 2200,
    surgeonFeeRange: [700, 1200],
    anesthesiaFee: 300,
    facilityFee: 500,
    roomChargesPerDay: 0,
  },
  {
    slug: "coronary-angioplasty",
    name: "Coronary Angioplasty (PTCA)",
    department: "Cardiology",
    summary: "Balloon dilation and stent placement to open narrowed coronary arteries.",
    description:
      "A catheter-based procedure to improve blood flow to the heart muscle. Often requires short hospital stay.",
    durationHours: 1.5,
    preparation: ["Cardiology evaluation and labs", "Fasting 6-8 hours prior", "Adjust medications per cardiologist"],
    risks: ["Bleeding", "Re-stenosis", "Heart attack (rare)", "Contrast reaction"],
    recoveryTime: "1-2 days in hospital; back to light activity within a week.",
    basePrice: 9500,
    surgeonFeeRange: [2000, 3500],
    anesthesiaFee: 900,
    facilityFee: 1500,
    roomChargesPerDay: 500,
  },
]
