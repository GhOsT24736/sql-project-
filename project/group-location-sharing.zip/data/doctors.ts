export type Doctor = {
  id: string
  name: string
  title: string
  specialty: string
  department: string
  experienceYears: number
  languages: string[]
  rating: number
  bio: string
  photoUrl: string
  surgeries: string[] // slugs
}

export const doctors: Doctor[] = [
  {
    id: "dr-jane-smith",
    name: "Dr. Jane Smith",
    title: "Consultant Orthopedic Surgeon",
    specialty: "Orthopedic Surgery",
    department: "Orthopedics",
    experienceYears: 12,
    languages: ["English", "Spanish"],
    rating: 4.8,
    bio: "Dr. Smith specializes in joint replacement and arthroscopic procedures with a focus on rapid recovery protocols.",
    photoUrl: "/orthopedic-surgeon-portrait.jpg",
    surgeries: ["total-knee-replacement"],
  },
  {
    id: "dr-rahul-mehta",
    name: "Dr. Rahul Mehta",
    title: "Consultant General Surgeon",
    specialty: "General Surgery",
    department: "General Surgery",
    experienceYears: 15,
    languages: ["English", "Hindi"],
    rating: 4.7,
    bio: "Dr. Mehta has extensive experience in laparoscopic procedures including appendectomy and hernia repair.",
    photoUrl: "/general-surgeon-portrait.jpg",
    surgeries: ["appendectomy"],
  },
  {
    id: "dr-lisa-cho",
    name: "Dr. Lisa Cho",
    title: "Senior Ophthalmologist",
    specialty: "Ophthalmology",
    department: "Ophthalmology",
    experienceYears: 18,
    languages: ["English", "Korean"],
    rating: 4.9,
    bio: "Dr. Cho is a cataract specialist focused on premium intraocular lenses and patient-centered outcomes.",
    photoUrl: "/ophthalmologist-portrait.jpg",
    surgeries: ["cataract-surgery"],
  },
  {
    id: "dr-omar-hassan",
    name: "Dr. Omar Hassan",
    title: "Interventional Cardiologist",
    specialty: "Cardiology",
    department: "Cardiology",
    experienceYears: 14,
    languages: ["English", "Arabic"],
    rating: 4.8,
    bio: "Dr. Hassan performs complex coronary interventions with a focus on radial access and enhanced recovery.",
    photoUrl: "/cardiologist-portrait.jpg",
    surgeries: ["coronary-angioplasty"],
  },
]
