export type Facility = {
  id: string
  name: string
  category: string
  description: string
  price: number
  unit: string
  prep?: string
  turnaround?: string
}

export const facilities: Facility[] = [
  {
    id: "xray-chest-pa",
    name: "X-ray Chest PA View",
    category: "Imaging",
    description: "Standard chest radiograph to evaluate lungs, heart size, and chest wall.",
    price: 60,
    unit: "per scan",
    prep: "Remove metallic objects",
    turnaround: "Same day",
  },
  {
    id: "ct-abdomen-contrast",
    name: "CT Abdomen with Contrast",
    category: "Imaging",
    description: "Cross-sectional imaging of the abdomen using IV contrast.",
    price: 450,
    unit: "per scan",
    prep: "Fasting 4-6 hours; check kidney function",
    turnaround: "24 hours",
  },
  {
    id: "mri-brain",
    name: "MRI Brain (without contrast)",
    category: "Imaging",
    description: "High-resolution MR imaging of the brain.",
    price: 700,
    unit: "per scan",
    prep: "Remove metal; MRI safety screening",
    turnaround: "24-48 hours",
  },
  {
    id: "cbc-test",
    name: "CBC (Complete Blood Count)",
    category: "Laboratory",
    description: "Measures red and white blood cells and platelets.",
    price: 25,
    unit: "per test",
    turnaround: "Same day",
  },
  {
    id: "pt-inr",
    name: "PT/INR",
    category: "Laboratory",
    description: "Assesses blood clotting time, often checked before surgery.",
    price: 30,
    unit: "per test",
    turnaround: "Same day",
  },
  {
    id: "physio-session",
    name: "Physiotherapy Session",
    category: "Therapy",
    description: "One-on-one rehab session with licensed physiotherapist.",
    price: 80,
    unit: "per session",
    turnaround: "By appointment",
  },
  {
    id: "private-room",
    name: "Private Room Charges",
    category: "Inpatient",
    description: "Daily charges for a private inpatient room.",
    price: 250,
    unit: "per day",
    turnaround: "N/A",
  },
  {
    id: "icu-bed",
    name: "ICU Bed Charges",
    category: "Inpatient",
    description: "Daily ICU bed charges including monitoring.",
    price: 450,
    unit: "per day",
    turnaround: "N/A",
  },
]
