"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Users, Plus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function CreateGroupPage() {
  const [groupName, setGroupName] = useState("")
  const [groupDescription, setGroupDescription] = useState("")
  const [emails, setEmails] = useState<string[]>([""])
  const router = useRouter()
  const { toast } = useToast()

  const addEmailField = () => {
    setEmails([...emails, ""])
  }

  const updateEmail = (index: number, value: string) => {
    const newEmails = [...emails]
    newEmails[index] = value
    setEmails(newEmails)
  }

  const removeEmail = (index: number) => {
    if (emails.length > 1) {
      const newEmails = [...emails]
      newEmails.splice(index, 1)
      setEmails(newEmails)
    }
  }

  const handleCreateGroup = () => {
    if (!groupName.trim()) {
      toast({
        title: "Group name required",
        description: "Please enter a name for your group",
        variant: "destructive",
      })
      return
    }

    // Simulate group creation
    toast({
      title: "Group created!",
      description: `Your group "${groupName}" has been created successfully.`,
    })

    // Redirect to groups page after a short delay
    setTimeout(() => {
      router.push("/groups")
    }, 1500)
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <Button variant="ghost" asChild className="mb-6">
        <Link href="/groups">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Groups
        </Link>
      </Button>

      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Create a New Group</h1>

        <Card>
          <CardHeader>
            <CardTitle>Group Details</CardTitle>
            <CardDescription>Set up your group for location sharing</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="group-name">Group Name</Label>
              <Input
                id="group-name"
                placeholder="Weekend Hangout, Family, Work Team, etc."
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="group-description">Description (Optional)</Label>
              <Textarea
                id="group-description"
                placeholder="What's this group for?"
                value={groupDescription}
                onChange={(e) => setGroupDescription(e.target.value)}
              />
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Invite Members</Label>
                <Button variant="ghost" size="sm" onClick={addEmailField}>
                  <Plus className="h-4 w-4 mr-1" /> Add More
                </Button>
              </div>

              {emails.map((email, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    placeholder="Email address"
                    type="email"
                    value={email}
                    onChange={(e) => updateEmail(index, e.target.value)}
                  />
                  {emails.length > 1 && (
                    <Button variant="ghost" size="icon" onClick={() => removeEmail(index)} className="flex-shrink-0">
                      &times;
                    </Button>
                  )}
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <h3 className="font-medium">Notification Settings</h3>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="instant-notifications">Instant Notifications</Label>
                  <p className="text-sm text-muted-foreground">Notify members immediately when locations are shared</p>
                </div>
                <Switch id="instant-notifications" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="location-recommendations">Location Recommendations</Label>
                  <p className="text-sm text-muted-foreground">Suggest nearby places based on shared locations</p>
                </div>
                <Switch id="location-recommendations" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="event-integration">Event Integration</Label>
                  <p className="text-sm text-muted-foreground">Notify about events happening near shared locations</p>
                </div>
                <Switch id="event-integration" defaultChecked />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full" onClick={handleCreateGroup}>
              <Users className="mr-2 h-4 w-4" /> Create Group
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
