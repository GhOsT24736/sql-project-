import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import Link from "next/link"
import { ThemeProvider } from "@/components/theme-provider"
import { Button } from "@/components/ui/button"
import { NotificationPanel } from "@/components/notification-panel"
import { Toaster } from "@/components/ui/toaster"
import { Users, MapPin, Settings } from "lucide-react"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Group Location Sharing",
  description: "Share locations with your group and get notified when others share theirs",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <Toaster />
          <div className="flex min-h-screen flex-col">
            <header className="border-b">
              <div className="container flex h-16 items-center justify-between px-4">
                <div className="flex items-center gap-6">
                  <Link href="/" className="flex items-center gap-2 font-semibold">
                    <MapPin className="h-5 w-5" />
                    <span>GroupLocator</span>
                  </Link>
                  <nav className="hidden md:flex gap-6">
                    <Link href="/groups" className="text-sm font-medium transition-colors hover:text-primary">
                      My Groups
                    </Link>
                    <Link href="/create-group" className="text-sm font-medium transition-colors hover:text-primary">
                      Create Group
                    </Link>
                    <Link href="/appointments" className="text-sm font-medium transition-colors hover:text-primary">
                      Appointments
                    </Link>
                  </nav>
                </div>
                <div className="flex items-center gap-4">
                  <NotificationPanel />
                  <Button variant="ghost" size="icon">
                    <Settings className="h-5 w-5" />
                  </Button>
                  <Button size="sm" asChild>
                    <Link href="/create-group">
                      <Users className="mr-2 h-4 w-4" /> New Group
                    </Link>
                  </Button>
                </div>
              </div>
            </header>
            <main className="flex-1">{children}</main>
            <footer className="border-t py-6">
              <div className="container flex flex-col items-center justify-between gap-4 px-4 md:flex-row">
                <p className="text-center text-sm text-muted-foreground md:text-left">
                  &copy; {new Date().getFullYear()} GroupLocator. All rights reserved.
                </p>
                <nav className="flex gap-4">
                  <Link href="#" className="text-sm text-muted-foreground hover:underline">
                    Privacy
                  </Link>
                  <Link href="#" className="text-sm text-muted-foreground hover:underline">
                    Terms
                  </Link>
                  <Link href="#" className="text-sm text-muted-foreground hover:underline">
                    Contact
                  </Link>
                </nav>
              </div>
            </footer>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}
