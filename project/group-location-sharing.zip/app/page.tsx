import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Stethoscope, ClipboardList, Building2, Calculator, ChevronRight } from "lucide-react"
import { siteConfig } from "@/data/site-config"
import { Badge } from "@/components/ui/badge"
import { departments } from "@/data/departments"
import { SiteHeader } from "@/components/site-header"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-neutral-50 to-neutral-100">
      <SiteHeader />
      <section className="mx-auto max-w-6xl px-4 py-10 md:py-16">
        <div className="grid gap-8 md:grid-cols-2 items-center">
          <div>
            <h1 className="text-3xl md:text-5xl font-semibold tracking-tight text-neutral-900">{siteConfig.name}</h1>
            <p className="mt-4 text-neutral-600 md:text-lg">
              Transparent, comprehensive information on doctors, surgeries, and facility services. Explore detailed
              procedures, surgeon profiles, and upfront pricing for surgeries, imaging, labs, and more. Built with
              Next.js App Router for modern, scalable routing and performance. [^1]
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild className="bg-emerald-600 hover:bg-emerald-700">
                <Link href="/surgeries">
                  <ClipboardList className="mr-2 h-4 w-4" />
                  Browse Surgeries
                </Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/doctors">
                  <Stethoscope className="mr-2 h-4 w-4" />
                  Find Doctors
                </Link>
              </Button>
              <Button asChild variant="secondary" className="bg-neutral-200 hover:bg-neutral-300 text-neutral-900">
                <Link href="/pricing">
                  <Calculator className="mr-2 h-4 w-4" />
                  Pricing & Estimator
                </Link>
              </Button>
            </div>
            <div className="mt-6 flex flex-wrap gap-2">
              {departments.slice(0, 8).map((d) => (
                <Badge key={d} variant="secondary" className="bg-white text-neutral-800 border">
                  {d}
                </Badge>
              ))}
            </div>
          </div>
          <div className="overflow-hidden rounded-xl border bg-white shadow-sm">
            <img
              src="/hospital-lobby-with-doctors-and-patients.jpg"
              alt="Hospital lobby with doctors and patients"
              className="h-full w-full object-cover"
            />
          </div>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ClipboardList className="h-5 w-5 text-emerald-600" />
                Surgeries
              </CardTitle>
              <CardDescription>Comprehensive procedure details and transparent pricing.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-neutral-600">
                Explore preparation, duration, risks, recovery timeline, and cost breakdown for each surgery.
              </p>
              <Button asChild variant="link" className="px-0 text-emerald-700 hover:text-emerald-800">
                <Link href="/surgeries">
                  View surgeries
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Stethoscope className="h-5 w-5 text-emerald-600" />
                Doctors
              </CardTitle>
              <CardDescription>Find the right specialist for your needs.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-neutral-600">
                Browse by specialty, experience, languages, and see which surgeries each doctor performs.
              </p>
              <Button asChild variant="link" className="px-0 text-emerald-700 hover:text-emerald-800">
                <Link href="/doctors">
                  View doctors
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-emerald-600" />
                Facilities & Imaging
              </CardTitle>
              <CardDescription>Upfront pricing for X-ray, CT, MRI, labs, and more.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-neutral-600">
                See service details, prep requirements, and turnaround times for diagnostics and support services.
              </p>
              <Button asChild variant="link" className="px-0 text-emerald-700 hover:text-emerald-800">
                <Link href="/facilities">
                  View facilities
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  )
}
