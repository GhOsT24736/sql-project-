import { NextResponse } from "next/server"

// Optional: If Resend is available and RESEND_API_KEY is set, we'll send a real email
async function trySendResendEmail(payload: any) {
  const apiKey = process.env.RESEND_API_KEY
  const toEmail = process.env.APPOINTMENTS_TO_EMAIL || payload.email // fallback to user
  if (!apiKey || !toEmail) return { used: false }

  const { Resend } = await import("resend")
  const resend = new Resend(apiKey)

  const subject = `New Appointment Request${payload.groupName ? ` - ${payload.groupName}` : ""}`
  const html = `
    <div>
      <h2>New Appointment Request</h2>
      <p><strong>Name:</strong> ${payload.name}</p>
      <p><strong>Email:</strong> ${payload.email}</p>
      ${payload.groupId ? `<p><strong>Group ID:</strong> ${payload.groupId}</p>` : ""}
      ${payload.groupName ? `<p><strong>Group Name:</strong> ${payload.groupName}</p>` : ""}
      <p><strong>Location:</strong> ${payload.location}</p>
      <p><strong>Date:</strong> ${payload.date}</p>
      <p><strong>Time:</strong> ${payload.time}</p>
      ${payload.message ? `<p><strong>Message:</strong> ${payload.message}</p>` : ""}
      <hr />
      <p>Sent from GroupLocator</p>
    </div>
  `

  await resend.emails.send({
    from: process.env.APPOINTMENTS_FROM_EMAIL || "GroupLocator <no-reply@your-domain.com>",
    to: toEmail,
    subject,
    html,
  })

  return { used: true }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    // Minimal server-side validation
    const required = ["name", "email", "location", "date", "time"]
    for (const k of required) {
      if (!body?.[k]) {
        return NextResponse.json({ ok: false, message: `Missing field: ${k}` }, { status: 400 })
      }
    }

    // Attempt to send via Resend (if configured)
    let sentViaResend = false
    try {
      const res = await trySendResendEmail(body)
      sentViaResend = !!res.used
    } catch (e) {
      // Swallow and fallback
      console.error("Resend sending error:", e)
    }

    // Always log payload server-side for observability
    console.log("Appointment request received:", JSON.stringify(body))

    const msg = sentViaResend
      ? "Your request was sent via email. Please check your inbox for confirmation."
      : "Email service not configured. Your request was received (dev mode)."

    return NextResponse.json({ ok: true, message: msg })
  } catch (e: any) {
    console.error("Appointment API error:", e)
    return NextResponse.json({ ok: false, message: "Unexpected error" }, { status: 500 })
  }
}
