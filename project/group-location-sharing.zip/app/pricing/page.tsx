import { SiteHeader } from "@/components/site-header"
import { PriceEstimator } from "@/components/price-estimator"
import { surgeries } from "@/data/surgeries"
import { facilities } from "@/data/facilities"
import { formatCurrency } from "@/lib/format"

export default function PricingPage() {
  return (
    <main className="min-h-screen bg-neutral-50">
      <SiteHeader />
      <section className="mx-auto max-w-6xl px-4 py-8 md:py-10">
        <h1 className="text-2xl md:text-3xl font-semibold text-neutral-900">Pricing & Estimator</h1>
        <p className="mt-2 text-neutral-600">
          Explore typical pricing for surgeries and hospital services. Use the estimator to plan your expected costs.
        </p>

        <div className="mt-8 grid gap-8 md:grid-cols-2">
          <PriceEstimator />
          <div className="space-y-6">
            <div className="rounded-lg border bg-white p-4">
              <h2 className="font-semibold text-neutral-900">Sample Surgery Costs</h2>
              <div className="mt-3 grid gap-2 text-sm">
                {surgeries.slice(0, 6).map((s) => (
                  <div key={s.slug} className="flex items-center justify-between">
                    <span className="text-neutral-700">{s.name}</span>
                    <span className="font-medium">{formatCurrency(s.basePrice)}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-lg border bg-white p-4">
              <h2 className="font-semibold text-neutral-900">Facility Services (examples)</h2>
              <div className="mt-3 grid gap-2 text-sm">
                {facilities.slice(0, 6).map((f) => (
                  <div key={f.id} className="flex items-center justify-between">
                    <span className="text-neutral-700">{f.name}</span>
                    <span className="font-medium">{formatCurrency(f.price)}</span>
                  </div>
                ))}
              </div>
              <p className="mt-2 text-xs text-neutral-500">
                {"Prices are indicative. Please contact admissions for finalized quotes."}
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
