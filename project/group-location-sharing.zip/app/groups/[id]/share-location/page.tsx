"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ArrowLeft, MapPin, Search, Mic, Send } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

// Mock data for demonstration
const suggestedLocations = [
  { id: 1, name: "Central Park", address: "New York, NY", distance: "0.5 miles away" },
  { id: 2, name: "The Coffee Shop", address: "123 Main St", distance: "0.8 miles away" },
  { id: 3, name: "Museum of Modern Art", address: "11 W 53rd St, New York", distance: "1.2 miles away" },
  { id: 4, name: "Grand Central Terminal", address: "89 E 42nd St, New York", distance: "1.5 miles away" },
]

export default function ShareLocationPage({ params }: { params: { id: string } }) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedLocation, setSelectedLocation] = useState<number | null>(null)
  const [isListening, setIsListening] = useState(false)
  const [message, setMessage] = useState("")
  const { toast } = useToast()

  const handleVoiceCommand = () => {
    setIsListening(true)

    // Simulate voice recognition after 2 seconds
    setTimeout(() => {
      setIsListening(false)
      setSelectedLocation(1) // Select Central Park
      setMessage("Let's meet here at 5 PM!")

      toast({
        title: "Voice command recognized",
        description: "Set Central Park for our group",
      })
    }, 2000)
  }

  const handleShareLocation = () => {
    if (!selectedLocation) {
      toast({
        title: "No location selected",
        description: "Please select a location to share",
        variant: "destructive",
      })
      return
    }

    const locationName = suggestedLocations.find((loc) => loc.id === selectedLocation)?.name

    toast({
      title: "Location shared!",
      description: `You've shared ${locationName} with your group members.`,
    })

    // Simulate notification to group members
    setTimeout(() => {
      toast({
        title: "Group notification sent",
        description: `All members have been notified about ${locationName}.`,
      })
    }, 1000)
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <Button variant="ghost" asChild className="mb-6">
        <Link href={`/groups/${params.id}`}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Group
        </Link>
      </Button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h1 className="text-3xl font-bold mb-6">Share Location</h1>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Search for a Location</CardTitle>
              <CardDescription>Find a place to share with your group</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2 mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    type="text"
                    placeholder="Search for a place..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Button
                  variant="outline"
                  size="icon"
                  className={isListening ? "bg-red-100 text-red-500" : ""}
                  onClick={handleVoiceCommand}
                >
                  <Mic className="h-4 w-4" />
                </Button>
              </div>

              {isListening && (
                <div className="text-center p-4 bg-muted rounded-md mb-4">
                  <p className="text-sm">Listening for voice command...</p>
                  <p className="text-xs text-muted-foreground mt-1">Try saying "Set Central Park for our group"</p>
                </div>
              )}

              <div className="space-y-2">
                <Label>Select a Location</Label>
                <RadioGroup
                  value={selectedLocation?.toString()}
                  onValueChange={(value) => setSelectedLocation(Number.parseInt(value))}
                >
                  {suggestedLocations.map((location) => (
                    <div key={location.id} className="flex items-center space-x-2 p-3 rounded-md hover:bg-muted">
                      <RadioGroupItem value={location.id.toString()} id={`location-${location.id}`} />
                      <Label htmlFor={`location-${location.id}`} className="flex-1 cursor-pointer">
                        <div className="font-medium">{location.name}</div>
                        <div className="text-sm text-gray-500">{location.address}</div>
                        <div className="text-xs text-gray-400">{location.distance}</div>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Add a Message</CardTitle>
              <CardDescription>Include details about the meetup</CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Let's meet here at 5 PM!"
                className="min-h-[100px]"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={handleShareLocation}>
                <Send className="mr-2 h-4 w-4" /> Share with Group
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Location Preview</CardTitle>
              <CardDescription>How your shared location will appear</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-video bg-muted rounded-md flex items-center justify-center mb-4">
                <div className="text-center">
                  {selectedLocation ? (
                    <>
                      <MapPin className="h-8 w-8 mx-auto mb-2 text-primary" />
                      <p className="font-medium">
                        {suggestedLocations.find((loc) => loc.id === selectedLocation)?.name}
                      </p>
                      <p className="text-sm text-gray-500">
                        {suggestedLocations.find((loc) => loc.id === selectedLocation)?.address}
                      </p>
                    </>
                  ) : (
                    <>
                      <MapPin className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-gray-500">Select a location to preview</p>
                    </>
                  )}
                </div>
              </div>

              {selectedLocation && (
                <div className="border rounded-md p-4">
                  <h3 className="font-medium mb-2">Notification Preview</h3>
                  <div className="bg-primary/10 p-4 rounded-md">
                    <div className="flex items-start gap-3">
                      <div className="bg-background p-2 rounded-full">
                        <MapPin className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">New location update!</p>
                        <p className="text-sm">
                          {suggestedLocations.find((loc) => loc.id === selectedLocation)?.name} has been chosen by You
                        </p>
                        {message && <p className="text-sm mt-2 italic">"{message}"</p>}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {selectedLocation && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Nearby Recommendations</CardTitle>
                <CardDescription>Events and places near this location</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-3 p-3 rounded-md hover:bg-muted">
                    <div className="bg-primary/10 p-2 rounded-full">
                      <MapPin className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Summer Concert Series</p>
                      <p className="text-sm text-gray-500">Outdoor event, 0.2 miles away</p>
                      <p className="text-xs text-gray-400">Today, 7:00 PM</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-md hover:bg-muted">
                    <div className="bg-primary/10 p-2 rounded-full">
                      <MapPin className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Lakeside Café</p>
                      <p className="text-sm text-gray-500">Restaurant, 0.3 miles away</p>
                      <p className="text-xs text-gray-400">Open until 10:00 PM</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-md hover:bg-muted">
                    <div className="bg-primary/10 p-2 rounded-full">
                      <MapPin className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Art Exhibition</p>
                      <p className="text-sm text-gray-500">Gallery, 0.5 miles away</p>
                      <p className="text-xs text-gray-400">Today, 10:00 AM - 8:00 PM</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
