import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Users, Settings, Clock, ArrowLeft, Plus } from "lucide-react"

// Mock data for demonstration
const group = {
  id: 1,
  name: "Weekend Hangout",
  members: [
    { id: 1, name: "John Doe", avatar: "/placeholder.svg?height=40&width=40" },
    { id: 2, name: "Jane Smith", avatar: "/placeholder.svg?height=40&width=40" },
    { id: 3, name: "Mike Johnson", avatar: "/placeholder.svg?height=40&width=40" },
    { id: 4, name: "Sarah Williams", avatar: "/placeholder.svg?height=40&width=40" },
    { id: 5, name: "Alex Brown", avatar: "/placeholder.svg?height=40&width=40" },
  ],
  locationHistory: [
    { id: 1, name: "Central Park", address: "New York, NY", sharedBy: "John Doe", timestamp: "Today, 2:30 PM" },
    { id: 2, name: "The Coffee Shop", address: "123 Main St", sharedBy: "Jane Smith", timestamp: "Yesterday, 5:15 PM" },
    {
      id: 3,
      name: "Museum of Modern Art",
      address: "11 W 53rd St, New York",
      sharedBy: "Mike Johnson",
      timestamp: "May 15, 3:00 PM",
    },
  ],
}

export default function GroupDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-6">
        <Button variant="ghost" asChild className="mb-4">
          <Link href="/groups">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Groups
          </Link>
        </Button>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">{group.name}</h1>
            <p className="text-gray-500 flex items-center mt-1">
              <Users className="mr-2 h-4 w-4" /> {group.members.length} members
            </p>
          </div>
          <div className="flex gap-2">
            <Button asChild>
              <Link href={`/groups/${params.id}/share-location`}>
                <MapPin className="mr-2 h-4 w-4" /> Share Location
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href={`/groups/${params.id}/settings`}>
                <Settings className="mr-2 h-4 w-4" /> Group Settings
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <Tabs defaultValue="locations" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="locations">Location History</TabsTrigger>
          <TabsTrigger value="members">Members</TabsTrigger>
          <TabsTrigger value="notifications">Notification Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="locations">
          <div className="space-y-4">
            {group.locationHistory.map((location) => (
              <Card key={location.id}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 p-3 rounded-full">
                      <MapPin className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                        <div>
                          <h3 className="font-semibold text-lg">{location.name}</h3>
                          <p className="text-gray-500">{location.address}</p>
                        </div>
                        <div className="flex items-center text-sm text-gray-400">
                          <Clock className="mr-1 h-3 w-3" /> {location.timestamp}
                        </div>
                      </div>
                      <p className="text-sm mt-2">
                        Shared by <span className="font-medium">{location.sharedBy}</span>
                      </p>
                      <div className="flex gap-2 mt-4">
                        <Button size="sm" variant="outline">
                          Get Directions
                        </Button>
                        <Button size="sm" variant="ghost">
                          View Details
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="members">
          <Card>
            <CardHeader>
              <CardTitle>Group Members</CardTitle>
              <CardDescription>People who can share and receive location updates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {group.members.map((member) => (
                  <div key={member.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                        <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{member.name}</p>
                      </div>
                    </div>
                    <Badge variant="outline">Active</Badge>
                  </div>
                ))}
              </div>
              <Button className="w-full mt-6">
                <Plus className="mr-2 h-4 w-4" /> Invite New Member
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Customize how you receive location updates</CardDescription>
            </CardHeader>
            <CardContent>
              <NotificationSettings />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function NotificationSettings() {
  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-medium">Instant Notifications</h3>
          <p className="text-sm text-gray-500">Get notified immediately when a location is shared</p>
        </div>
        <Switch checked={true} />
      </div>

      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-medium">Daily Summary</h3>
          <p className="text-sm text-gray-500">Receive a daily digest of all shared locations</p>
        </div>
        <Switch checked={false} />
      </div>

      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-medium">Location-based Filters</h3>
          <p className="text-sm text-gray-500">Only notify for locations within a certain distance</p>
        </div>
        <Switch checked={true} />
      </div>

      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-medium">Email Notifications</h3>
          <p className="text-sm text-gray-500">Also send notifications to your email</p>
        </div>
        <Switch checked={false} />
      </div>

      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-medium">Event Recommendations</h3>
          <p className="text-sm text-gray-500">Get notified about events near shared locations</p>
        </div>
        <Switch checked={true} />
      </div>
    </div>
  )
}

// Import Switch component
import { Switch } from "@/components/ui/switch"
