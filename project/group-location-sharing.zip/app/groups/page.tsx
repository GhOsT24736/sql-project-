import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Users, Plus } from "lucide-react"

// Mock data for demonstration
const groups = [
  {
    id: 1,
    name: "Weekend Hangout",
    members: 5,
    lastLocation: "Central Park",
    lastUpdated: "2 hours ago",
    notifications: 3,
  },
  {
    id: 2,
    name: "Family",
    members: 4,
    lastLocation: "Mom's House",
    lastUpdated: "1 day ago",
    notifications: 0,
  },
  {
    id: 3,
    name: "Work Team",
    members: 8,
    lastLocation: "Conference Center",
    lastUpdated: "3 hours ago",
    notifications: 1,
  },
]

export default function GroupsPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">My Groups</h1>
        <Button asChild>
          <Link href="/create-group">
            <Plus className="mr-2 h-4 w-4" /> Create New Group
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {groups.map((group) => (
          <Card key={group.id} className="relative">
            {group.notifications > 0 && (
              <Badge className="absolute top-4 right-4 bg-red-500" variant="secondary">
                {group.notifications} new
              </Badge>
            )}
            <CardHeader>
              <CardTitle>{group.name}</CardTitle>
              <CardDescription className="flex items-center">
                <Users className="mr-1 h-4 w-4" /> {group.members} members
              </CardDescription>
            </CardHeader>
            <CardContent>
              {group.lastLocation && (
                <div className="flex items-start mb-2">
                  <MapPin className="mr-2 h-4 w-4 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-medium">Last shared location:</p>
                    <p className="text-sm text-gray-500">{group.lastLocation}</p>
                    <p className="text-xs text-gray-400">{group.lastUpdated}</p>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" size="sm" asChild>
                <Link href={`/groups/${group.id}`}>View Details</Link>
              </Button>
              <Button variant="ghost" size="sm" asChild>
                <Link href={`/groups/${group.id}/share-location`}>
                  <MapPin className="mr-2 h-4 w-4" /> Share Location
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
