import { SiteHeader } from "@/components/site-header"
import { doctors } from "@/data/doctors"
import { DoctorCard } from "@/components/doctor-card"
import { SearchAndFilter } from "@/components/search-and-filter"
import { Suspense } from "react"

function filterDoctors(query: string, category?: string) {
  const q = query.trim().toLowerCase()
  return doctors.filter((d) => {
    const matchesQuery =
      !q ||
      d.name.toLowerCase().includes(q) ||
      d.specialty.toLowerCase().includes(q) ||
      d.department.toLowerCase().includes(q)
    const matchesCategory = !category || d.department === category || d.specialty === category
    return matchesQuery && matchesCategory
  })
}

export default function DoctorsPage({ searchParams }: { searchParams?: Record<string, string | string[]> }) {
  const query = typeof searchParams?.q === "string" ? searchParams?.q : ""
  const cat = typeof searchParams?.c === "string" ? searchParams?.c : undefined
  const categories = Array.from(new Set(doctors.flatMap((d) => [d.department, d.specialty])))

  const list = filterDoctors(query, cat)

  return (
    <main className="min-h-screen bg-neutral-50">
      <SiteHeader />
      <section className="mx-auto max-w-6xl px-4 py-8 md:py-10">
        <h1 className="text-2xl md:text-3xl font-semibold text-neutral-900">Our Doctors</h1>
        <p className="mt-2 text-neutral-600">Browse by specialty, department, or name.</p>

        <div className="mt-6">
          <Suspense>
            {/* Client filter */}
            <SearchAndFilter placeholder="Search doctors by name, specialty, or department" categories={categories} />
          </Suspense>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {list.map((d) => (
            <DoctorCard key={d.id} {...d} />
          ))}
        </div>
      </section>
    </main>
  )
}
