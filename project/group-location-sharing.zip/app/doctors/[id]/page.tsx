import { notFound } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { doctors } from "@/data/doctors"
import { surgeries } from "@/data/surgeries"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { formatCurrency } from "@/lib/format"

export default function DoctorDetailPage({ params }: { params: { id: string } }) {
  const doc = doctors.find((d) => d.id === params.id)
  if (!doc) return notFound()
  const docSurgeries = doc.surgeries.map((slug) => surgeries.find((s) => s.slug === slug)).filter(Boolean)

  return (
    <main className="min-h-screen bg-neutral-50">
      <SiteHeader />
      <section className="mx-auto max-w-5xl px-4 py-8 md:py-10">
        <div className="grid gap-6 md:grid-cols-[200px_1fr]">
          <img
            src={doc.photoUrl || "/placeholder.svg"}
            alt={`${doc.name} profile photo`}
            className="h-48 w-full rounded-lg object-cover md:h-56"
          />
          <div>
            <h1 className="text-2xl font-semibold text-neutral-900">{doc.name}</h1>
            <div className="text-neutral-600">{doc.title}</div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge variant="secondary" className="bg-neutral-100 text-neutral-800">
                {doc.specialty}
              </Badge>
              <Badge variant="secondary" className="bg-emerald-50 text-emerald-800">
                {doc.department}
              </Badge>
              <Badge variant="outline">{doc.experienceYears} yrs experience</Badge>
              <Badge variant="outline">{doc.rating.toFixed(1)} rating</Badge>
            </div>
            <p className="mt-4 text-neutral-700">{doc.bio}</p>
            <div className="mt-3 flex flex-wrap gap-1">
              {doc.languages.map((l) => (
                <Badge key={l} variant="outline" className="border-neutral-300">
                  {l}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-8">
          <h2 className="text-xl font-semibold text-neutral-900">Surgeries performed</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            {docSurgeries.map((s) => {
              const x = s!
              return (
                <Card key={x.slug}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{x.name}</span>
                      <Badge variant="secondary" className="bg-emerald-50 text-emerald-800">
                        {x.department}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-neutral-700">
                    <p className="line-clamp-3">{x.description}</p>
                    <div className="mt-2 flex flex-wrap gap-4">
                      <span>Duration: {x.durationHours}h</span>
                      <span>Base: {formatCurrency(x.basePrice)}</span>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>
    </main>
  )
}
