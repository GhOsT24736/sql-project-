import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function NotFound() {
  return (
    <main className="grid min-h-[60vh] place-items-center bg-neutral-50 px-4">
      <div className="text-center">
        <h1 className="text-3xl font-semibold text-neutral-900">Not Found</h1>
        <p className="mt-2 text-neutral-600">{"We couldn't find the page you're looking for."}</p>
        <Button asChild className="mt-6 bg-emerald-600 hover:bg-emerald-700">
          <Link href="/">Go Home</Link>
        </Button>
      </div>
    </main>
  )
}
