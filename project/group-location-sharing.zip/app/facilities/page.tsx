import { SiteHeader } from "@/components/site-header"
import { facilities } from "@/data/facilities"
import { FacilityCard } from "@/components/facility-card"
import { SearchAndFilter } from "@/components/search-and-filter"

function filterFacilities(query: string, category?: string) {
  const q = query.trim().toLowerCase()
  return facilities.filter((f) => {
    const matchesQuery = !q || f.name.toLowerCase().includes(q) || f.description.toLowerCase().includes(q)
    const matchesCategory = !category || f.category === category
    return matchesQuery && matchesCategory
  })
}

export default function FacilitiesPage({ searchParams }: { searchParams?: Record<string, string | string[]> }) {
  const query = typeof searchParams?.q === "string" ? searchParams?.q : ""
  const cat = typeof searchParams?.c === "string" ? searchParams?.c : undefined
  const categories = Array.from(new Set(facilities.map((f) => f.category)))
  const list = filterFacilities(query, cat)

  return (
    <main className="min-h-screen bg-neutral-50">
      <SiteHeader />
      <section className="mx-auto max-w-6xl px-4 py-8 md:py-10">
        <h1 className="text-2xl md:text-3xl font-semibold text-neutral-900">Facilities & Services</h1>
        <p className="mt-2 text-neutral-600">Imaging, labs, therapy, and other hospital services with clear pricing.</p>

        <div className="mt-6">
          <SearchAndFilter placeholder="Search facilities or services" categories={categories} />
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {list.map((f) => (
            <FacilityCard key={f.id} {...f} />
          ))}
        </div>
      </section>
    </main>
  )
}
