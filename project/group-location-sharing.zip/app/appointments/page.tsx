"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Calendar, Clock, Mail, MapPin, User, CheckCircle2, Users } from "lucide-react"
import Link from "next/link"

// Mock groups for convenience; in a real app load from DB.
const groups = [
  { id: "1", name: "Weekend Hangout" },
  { id: "2", name: "Family" },
  { id: "3", name: "Work Team" },
]

const AppointmentSchema = z.object({
  name: z.string().min(2, "Please enter your name"),
  email: z.string().email("Enter a valid email"),
  groupId: z.string().optional(),
  groupName: z.string().optional(),
  location: z.string().min(2, "Please specify a location"),
  date: z.string().min(1, "Please select a date"),
  time: z.string().min(1, "Please select a time"),
  message: z.string().optional(),
})

type AppointmentValues = z.infer<typeof AppointmentSchema>

export default function AppointmentsPage() {
  const router = useRouter()
  const [success, setSuccess] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const form = useForm<AppointmentValues>({
    resolver: zodResolver(AppointmentSchema),
    defaultValues: {
      name: "",
      email: "",
      groupId: "",
      groupName: "",
      location: "",
      date: "",
      time: "",
      message: "",
    },
  })

  const onSubmit = async (values: AppointmentValues) => {
    setSuccess(null)
    setError(null)
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      })
      const data = (await res.json()) as { ok: boolean; message?: string }
      if (!res.ok || !data.ok) {
        throw new Error(data?.message || "Failed to submit request")
      }
      setSuccess(
        data?.message ||
          "Your appointment request has been submitted. We’ve sent a confirmation email if email is configured.",
      )
      form.reset()
    } catch (e: any) {
      setError(e?.message || "Something went wrong. Please try again.")
    }
  }

  const isSubmitting = form.formState.isSubmitting

  return (
    <div className="container mx-auto max-w-3xl px-4 py-10 md:py-12">
      <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold md:text-3xl">Request or Schedule an Appointment</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Submit your preferred date, time, and location. We’ll notify your group and send you a confirmation.
          </p>
        </div>
        <Button asChild variant="outline">
          <Link href="/groups">
            <Users className="mr-2 h-4 w-4" />
            View Groups
          </Link>
        </Button>
      </div>

      {success ? (
        <Alert className="mb-6 border-emerald-300 bg-emerald-50 text-emerald-900">
          <CheckCircle2 className="h-4 w-4" />
          <AlertTitle>Request received</AlertTitle>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      ) : null}

      {error ? (
        <Alert className="mb-6 border-red-300 bg-red-50 text-red-900">
          <AlertTitle>Submission failed</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Appointment Details</CardTitle>
          <CardDescription>Fill out the form and we’ll handle the rest.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Your Name</Label>
              <div className="relative">
                <User className="pointer-events-none absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="name" placeholder="Jane Doe" className="pl-8" {...form.register("name")} />
              </div>
              {form.formState.errors.name?.message ? (
                <p className="text-sm text-red-600">{form.formState.errors.name.message}</p>
              ) : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="email" placeholder="you@example.com" className="pl-8" {...form.register("email")} />
              </div>
              {form.formState.errors.email?.message ? (
                <p className="text-sm text-red-600">{form.formState.errors.email.message}</p>
              ) : null}
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Group (optional)</Label>
              <Select
                value={form.getValues("groupId") || "none"}
                onValueChange={(v) => {
                  form.setValue("groupId", v)
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select your group" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No group</SelectItem>
                  {groups.map((g) => (
                    <SelectItem key={g.id} value={g.id}>
                      {g.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Don’t see your group? You can still request an appointment without selecting one.
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="groupName">Or enter a group name</Label>
              <Input id="groupName" placeholder="e.g., Weekend Hangout" {...form.register("groupName")} />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <div className="relative">
              <MapPin className="pointer-events-none absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                id="location"
                placeholder="Central Park, New York, NY"
                className="pl-8"
                {...form.register("location")}
              />
            </div>
            {form.formState.errors.location?.message ? (
              <p className="text-sm text-red-600">{form.formState.errors.location.message}</p>
            ) : null}
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <div className="relative">
                <Calendar className="pointer-events-none absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="date" type="date" className="pl-8" {...form.register("date")} />
              </div>
              {form.formState.errors.date?.message ? (
                <p className="text-sm text-red-600">{form.formState.errors.date.message}</p>
              ) : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="time">Time</Label>
              <div className="relative">
                <Clock className="pointer-events-none absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="time" type="time" className="pl-8" {...form.register("time")} />
              </div>
              {form.formState.errors.time?.message ? (
                <p className="text-sm text-red-600">{form.formState.errors.time.message}</p>
              ) : null}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Message (optional)</Label>
            <Textarea
              id="message"
              placeholder="Any details we should know?"
              className="min-h-[100px]"
              {...form.register("message")}
            />
          </div>
        </CardContent>
        <CardFooter className="flex items-center justify-between">
          <Button type="button" variant="outline" asChild>
            <Link href="/groups">Cancel</Link>
          </Button>
          <Button onClick={form.handleSubmit(onSubmit)} disabled={isSubmitting}>
            {isSubmitting ? "Submitting..." : "Submit Request"}
          </Button>
        </CardFooter>
      </Card>

      <div className="mt-6 text-xs text-muted-foreground">
        Tip: Configure RESEND_API_KEY and APPOINTMENTS_TO_EMAIL in your project to enable outgoing emails.
      </div>
    </div>
  )
}
