import { SiteHeader } from "@/components/site-header"
import { surgeries } from "@/data/surgeries"
import { SurgeryCard } from "@/components/surgery-card"
import { SearchAndFilter } from "@/components/search-and-filter"

function filterSurgeries(query: string, category?: string) {
  const q = query.trim().toLowerCase()
  return surgeries.filter((s) => {
    const matchesQuery = !q || s.name.toLowerCase().includes(q) || s.department.toLowerCase().includes(q)
    const matchesCategory = !category || s.department === category
    return matchesQuery && matchesCategory
  })
}

export default function SurgeriesPage({ searchParams }: { searchParams?: Record<string, string | string[]> }) {
  const query = typeof searchParams?.q === "string" ? searchParams?.q : ""
  const cat = typeof searchParams?.c === "string" ? searchParams?.c : undefined
  const categories = Array.from(new Set(surgeries.map((s) => s.department)))

  const list = filterSurgeries(query, cat)

  return (
    <main className="min-h-screen bg-neutral-50">
      <SiteHeader />
      <section className="mx-auto max-w-6xl px-4 py-8 md:py-10">
        <h1 className="text-2xl md:text-3xl font-semibold text-neutral-900">Surgeries & Procedures</h1>
        <p className="mt-2 text-neutral-600">Detailed descriptions, preparation, risks, recovery, and pricing.</p>

        <div className="mt-6">
          <SearchAndFilter placeholder="Search surgeries by name or department" categories={categories} />
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {list.map((s) => (
            <SurgeryCard
              key={s.slug}
              slug={s.slug}
              name={s.name}
              department={s.department}
              durationHours={s.durationHours}
              basePrice={s.basePrice}
              summary={s.summary}
            />
          ))}
        </div>
      </section>
    </main>
  )
}
