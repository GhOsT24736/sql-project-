import { notFound } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { surgeries } from "@/data/surgeries"
import { Badge } from "@/components/ui/badge"
import { formatCurrency } from "@/lib/format"

export default function SurgeryDetailPage({ params }: { params: { slug: string } }) {
  const item = surgeries.find((s) => s.slug === params.slug)
  if (!item) return notFound()

  const {
    name,
    department,
    description,
    durationHours,
    preparation,
    risks,
    recoveryTime,
    basePrice,
    surgeonFeeRange,
    anesthesiaFee,
    facilityFee,
    roomChargesPerDay,
  } = item

  return (
    <main className="min-h-screen bg-neutral-50">
      <SiteHeader />
      <section className="mx-auto max-w-5xl px-4 py-8 md:py-10">
        <header className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-neutral-900">{name}</h1>
            <div className="mt-1">
              <Badge variant="secondary" className="bg-emerald-50 text-emerald-800">
                {department}
              </Badge>
            </div>
          </div>
          <img src="/operating-room-surgery.jpg" alt="Operating room" className="h-28 w-52 rounded object-cover" />
        </header>

        <div className="mt-6 grid gap-6 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6">
            <section>
              <h2 className="text-lg font-semibold text-neutral-900">Overview</h2>
              <p className="mt-2 text-neutral-700">{description}</p>
              <div className="mt-3 text-sm text-neutral-600">Typical duration: {durationHours} hours</div>
            </section>

            <section>
              <h3 className="text-lg font-semibold text-neutral-900">Preparation</h3>
              <ul className="mt-2 list-disc pl-5 text-neutral-700">
                {preparation.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold text-neutral-900">Risks</h3>
              <ul className="mt-2 list-disc pl-5 text-neutral-700">
                {risks.map((r) => (
                  <li key={r}>{r}</li>
                ))}
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold text-neutral-900">Recovery</h3>
              <p className="mt-2 text-neutral-700">{recoveryTime}</p>
            </section>
          </div>

          <aside className="space-y-4">
            <div className="rounded-lg border bg-white p-4">
              <h3 className="font-semibold text-neutral-900">Pricing Breakdown</h3>
              <div className="mt-3 grid gap-2 text-sm">
                <div className="flex justify-between">
                  <span>Base procedure</span>
                  <span className="font-medium">{formatCurrency(basePrice)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Surgeon fee (range)</span>
                  <span className="font-medium">
                    {formatCurrency(surgeonFeeRange[0])} - {formatCurrency(surgeonFeeRange[1])}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Anesthesia</span>
                  <span className="font-medium">{formatCurrency(anesthesiaFee)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Facility fee</span>
                  <span className="font-medium">{formatCurrency(facilityFee)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Room charges (per day)</span>
                  <span className="font-medium">{formatCurrency(roomChargesPerDay)}</span>
                </div>
              </div>
              <p className="mt-2 text-xs text-neutral-500">
                {"The above are typical ranges before insurance. Actual costs vary based on clinical factors."}
              </p>
            </div>
          </aside>
        </div>
      </section>
    </main>
  )
}
