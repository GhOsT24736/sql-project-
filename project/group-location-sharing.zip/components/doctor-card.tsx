"use client"

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Stethoscope, Star } from "lucide-react"

export type DoctorCardProps = {
  id: string
  name: string
  title: string
  specialty: string
  department: string
  experienceYears: number
  languages: string[]
  rating: number
  photoUrl?: string
  surgeries?: string[]
}

export function DoctorCard(
  props: DoctorCardProps = {
    id: "d1",
    name: "Dr. Jane Smith",
    title: "Consultant Surgeon",
    specialty: "Orthopedic Surgery",
    department: "Orthopedics",
    experienceYears: 12,
    languages: ["English"],
    rating: 4.8,
    photoUrl: "/doctor-portrait.png",
    surgeries: ["total-knee-replacement"],
  },
) {
  const {
    id,
    name,
    title,
    specialty,
    department,
    experienceYears,
    languages,
    rating,
    photoUrl = "/doctor-portrait.png",
    surgeries = [],
  } = props

  return (
    <Card className="overflow-hidden">
      <CardHeader className="flex flex-row items-center gap-4">
        <img
          src={photoUrl || "/placeholder.svg"}
          alt={`${name} profile photo`}
          className="h-20 w-20 rounded-md object-cover"
        />
        <div>
          <CardTitle className="text-lg">{name}</CardTitle>
          <div className="text-sm text-neutral-600">{title}</div>
          <div className="mt-1 flex flex-wrap gap-2">
            <Badge variant="secondary" className="bg-neutral-100 text-neutral-800">
              {specialty}
            </Badge>
            <Badge variant="secondary" className="bg-emerald-50 text-emerald-800">
              {department}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="grid gap-2 text-sm text-neutral-700">
        <div className="flex items-center gap-2">
          <Stethoscope className="h-4 w-4 text-neutral-500" />
          <span>{experienceYears} years experience</span>
        </div>
        <div className="flex items-center gap-2">
          <Star className="h-4 w-4 text-amber-500" />
          <span>{rating.toFixed(1)} rating</span>
        </div>
        <div className="flex flex-wrap gap-1">
          {languages.map((l) => (
            <Badge key={l} variant="outline" className="border-neutral-300 text-neutral-700">
              {l}
            </Badge>
          ))}
        </div>
      </CardContent>
      <CardFooter className="flex items-center justify-between">
        <div className="text-xs text-neutral-500">{surgeries.length} surgeries</div>
        <Button asChild variant="outline" size="sm">
          <Link href={`/doctors/${id}`}>View Profile</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
