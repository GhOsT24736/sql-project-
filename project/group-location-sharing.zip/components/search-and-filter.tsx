"use client"

import { useMemo, useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"

export type SearchAndFilterProps = {
  placeholder?: string
  categories?: string[]
  onChange?: (q: { query: string; category?: string }) => void
  defaultCategoryLabel?: string
}

export function SearchAndFilter(
  props: SearchAndFilterProps = {
    placeholder: "Search...",
    categories: ["All"],
    onChange: () => {},
    defaultCategoryLabel: "All",
  },
) {
  const { placeholder = "Search...", categories = ["All"], onChange, defaultCategoryLabel = "All" } = props
  const [query, setQuery] = useState("")
  const [category, setCategory] = useState<string | undefined>(undefined)

  const resolvedCategories = useMemo(() => {
    const base = [defaultCategoryLabel]
    return Array.from(new Set([...(categories || []), ...base]))
  }, [categories, defaultCategoryLabel])

  return (
    <div className="grid gap-3 md:grid-cols-[1fr_240px]">
      <div className="grid gap-1.5">
        <Label htmlFor="search">Search</Label>
        <div className="relative">
          <Input
            id="search"
            placeholder={placeholder}
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              onChange?.({ query: e.target.value, category })
            }}
            aria-label="Search"
          />
          {query ? (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-1 top-1 h-8 w-8 text-neutral-500"
              onClick={() => {
                setQuery("")
                onChange?.({ query: "", category })
              }}
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Clear</span>
            </Button>
          ) : null}
        </div>
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="category">Filter</Label>
        <Select
          value={category ?? defaultCategoryLabel}
          onValueChange={(v) => {
            const value = v === defaultCategoryLabel ? undefined : v
            setCategory(value)
            onChange?.({ query, category: value })
          }}
        >
          <SelectTrigger id="category" aria-label="Category filter">
            <SelectValue placeholder="Select" />
          </SelectTrigger>
          <SelectContent>
            {resolvedCategories.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  )
}
