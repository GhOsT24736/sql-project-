"use client"

import { useMemo, useState } from "react"
import { surgeries } from "@/data/surgeries"
import { facilities } from "@/data/facilities"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { formatCurrency } from "@/lib/format"

export function PriceEstimator() {
  const [surgerySlug, setSurgerySlug] = useState(surgeries[0]?.slug ?? "")
  const [lengthOfStay, setLengthOfStay] = useState(2)
  const [selectedFacilities, setSelectedFacilities] = useState<string[]>([])

  const surgery = useMemo(() => surgeries.find((s) => s.slug === surgerySlug), [surgerySlug])

  const total = useMemo(() => {
    if (!surgery) return 0
    const base = surgery.basePrice
    const surgeonFeeAvg = (surgery.surgeonFeeRange[0] + surgery.surgeonFeeRange[1]) / 2
    const anesthesia = surgery.anesthesiaFee
    const facility = surgery.facilityFee
    const room = surgery.roomChargesPerDay * Math.max(0, lengthOfStay)
    const extras = selectedFacilities
      .map((id) => facilities.find((f) => f.id === id)?.price ?? 0)
      .reduce((a, b) => a + b, 0)
    return base + surgeonFeeAvg + anesthesia + facility + room + extras
  }, [surgery, lengthOfStay, selectedFacilities])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Estimate Your Surgery Cost</CardTitle>
        <CardDescription>
          {"Select a surgery, optional add-ons, and estimate length of stay to see an approximate total."}
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-6">
        <div className="grid gap-3 md:grid-cols-2">
          <div className="grid gap-1.5">
            <Label htmlFor="surgery">Surgery</Label>
            <Select value={surgerySlug} onValueChange={setSurgerySlug}>
              <SelectTrigger id="surgery">
                <SelectValue placeholder="Select surgery" />
              </SelectTrigger>
              <SelectContent>
                {surgeries.map((s) => (
                  <SelectItem key={s.slug} value={s.slug}>
                    {s.name} {"("}
                    {s.department}
                    {")"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="stay">Length of stay (days)</Label>
            <Input
              id="stay"
              type="number"
              min={0}
              max={30}
              value={lengthOfStay}
              onChange={(e) => setLengthOfStay(Number(e.target.value))}
            />
          </div>
        </div>

        <div className="grid gap-2">
          <Label>Optional services</Label>
          <div className="grid gap-2 md:grid-cols-2">
            {facilities.slice(0, 8).map((f) => {
              const checked = selectedFacilities.includes(f.id)
              return (
                <label key={f.id} className="flex items-start gap-3 rounded border p-3">
                  <Checkbox
                    checked={checked}
                    onCheckedChange={(v) => {
                      const val = Boolean(v)
                      setSelectedFacilities((prev) => (val ? [...prev, f.id] : prev.filter((id) => id !== f.id)))
                    }}
                  />
                  <div className="text-sm">
                    <div className="font-medium">{f.name}</div>
                    <div className="text-neutral-600">
                      {formatCurrency(f.price)} {"("}
                      {f.unit}
                      {")"}
                    </div>
                  </div>
                </label>
              )
            })}
          </div>
        </div>

        <div className="rounded-lg border bg-neutral-50 p-4">
          <div className="text-sm text-neutral-600">Estimated total</div>
          <div className="text-2xl font-semibold text-neutral-900">{formatCurrency(total)}</div>
          <div className="mt-1 text-xs text-neutral-500">
            {
              "This is an estimate. Actual costs vary based on clinical needs, insurance coverage, and physician assessment."
            }
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
