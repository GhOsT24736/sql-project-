"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Menu } from "lucide-react"
import { siteConfig } from "@/data/site-config"

const nav = [
  { href: "/", label: "Home" },
  { href: "/surgeries", label: "Surgeries" },
  { href: "/doctors", label: "Doctors" },
  { href: "/facilities", label: "Facilities" },
  { href: "/pricing", label: "Pricing" },
]

export function SiteHeader() {
  const pathname = usePathname()
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-white/80 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <span className="inline-flex h-7 w-7 items-center justify-center rounded bg-emerald-600 text-white">H</span>
          <span className="text-neutral-900">{siteConfig.nameShort}</span>
        </Link>

        <nav className="hidden gap-6 md:flex">
          {nav.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={cn(
                "text-sm font-medium text-neutral-700 hover:text-neutral-900",
                pathname === n.href && "text-neutral-900 underline underline-offset-8",
              )}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button asChild className="hidden md:inline-flex bg-emerald-600 hover:bg-emerald-700">
            <Link href="/pricing">Get Estimate</Link>
          </Button>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="md:hidden bg-transparent">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Open menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-64">
              <nav className="grid gap-3 pt-6">
                {nav.map((n) => (
                  <Link
                    key={n.href}
                    href={n.href}
                    className={cn(
                      "rounded px-2 py-1.5 text-sm hover:bg-neutral-100",
                      pathname === n.href && "bg-neutral-100 font-medium",
                    )}
                  >
                    {n.label}
                  </Link>
                ))}
                <Button asChild className="mt-2 bg-emerald-600 hover:bg-emerald-700">
                  <Link href="/pricing">Get Estimate</Link>
                </Button>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
