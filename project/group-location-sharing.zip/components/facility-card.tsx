"use client"

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { formatCurrency } from "@/lib/format"

export type FacilityCardProps = {
  id: string
  name: string
  category: string
  description: string
  price: number
  unit: string
  prep?: string
  turnaround?: string
}

export function FacilityCard(
  props: FacilityCardProps = {
    id: "mri-brain",
    name: "MRI Brain (without contrast)",
    category: "Imaging",
    description: "High-resolution magnetic resonance imaging of the brain.",
    price: 700,
    unit: "per scan",
    prep: "Remove metal objects; screening required.",
    turnaround: "24-48 hours for report",
  },
) {
  const { name, category, description, price, unit, prep, turnaround } = props
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between gap-2">
          <span>{name}</span>
          <Badge variant="secondary" className="bg-neutral-100 text-neutral-800">
            {category}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2 text-sm text-neutral-700">
        <p>{description}</p>
        <div className="flex flex-wrap items-center gap-4">
          <span className="font-medium text-neutral-900">
            {formatCurrency(price)} <span className="text-neutral-500 font-normal">({unit})</span>
          </span>
          {prep ? <span className="text-neutral-600">Prep: {prep}</span> : null}
          {turnaround ? <span className="text-neutral-600">TAT: {turnaround}</span> : null}
        </div>
      </CardContent>
      <CardFooter className="justify-end">
        <Button variant="outline" size="sm">
          Learn more
        </Button>
      </CardFooter>
    </Card>
  )
}
