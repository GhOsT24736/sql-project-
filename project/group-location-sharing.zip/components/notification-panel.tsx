"use client"

import { useState, useEffect } from "react"
import { Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"

// Mock notifications for demonstration
const initialNotifications = [
  {
    id: 1,
    title: "New location update!",
    message: "John has selected Central Park as a meetup spot!",
    time: "2 minutes ago",
    read: false,
    group: "Weekend Hangout",
  },
  {
    id: 2,
    title: "New location update!",
    message: "Sarah has selected The Coffee Shop for tomorrow's meeting.",
    time: "1 hour ago",
    read: false,
    group: "Work Team",
  },
  {
    id: 3,
    title: "Event near shared location",
    message: "There's a concert happening near Central Park tonight!",
    time: "3 hours ago",
    read: true,
    group: "Weekend Hangout",
  },
]

export function NotificationPanel() {
  const [notifications, setNotifications] = useState(initialNotifications)
  const [isOpen, setIsOpen] = useState(false)

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })))
  }

  const markAsRead = (id: number) => {
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  // Simulate receiving a new notification
  useEffect(() => {
    const timer = setTimeout(() => {
      const newNotification = {
        id: 4,
        title: "New location update!",
        message: "Mike has selected Museum of Modern Art for this weekend.",
        time: "Just now",
        read: false,
        group: "Weekend Hangout",
      }

      setNotifications((prev) => [newNotification, ...prev])
    }, 10000) // Add a new notification after 10 seconds

    return () => clearTimeout(timer)
  }, [])

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge
              className="absolute -top-2 -right-2 px-1.5 py-0.5 min-w-[1.25rem] h-5 flex items-center justify-center"
              variant="destructive"
            >
              {unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <Card className="border-0 shadow-none">
          <CardHeader className="flex flex-row items-center justify-between py-4 px-4 border-b">
            <CardTitle className="text-lg">Notifications</CardTitle>
            {unreadCount > 0 && (
              <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                Mark all as read
              </Button>
            )}
          </CardHeader>
          <CardContent className="p-0 max-h-[400px] overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="py-6 text-center text-muted-foreground">No notifications</div>
            ) : (
              <div>
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 border-b last:border-0 hover:bg-muted/50 cursor-pointer ${!notification.read ? "bg-primary/5" : ""}`}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className="flex items-start gap-2">
                      <div className="flex-shrink-0 mt-1">
                        {!notification.read && <div className="w-2 h-2 rounded-full bg-primary" />}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{notification.title}</p>
                        <p className="text-sm">{notification.message}</p>
                        <div className="flex justify-between mt-1">
                          <p className="text-xs text-muted-foreground">{notification.group}</p>
                          <p className="text-xs text-muted-foreground">{notification.time}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </PopoverContent>
    </Popover>
  )
}
