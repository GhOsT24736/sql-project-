"use client"

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Info } from "lucide-react"
import { formatCurrency } from "@/lib/format"

export type SurgeryCardProps = {
  slug: string
  name: string
  department: string
  durationHours: number
  basePrice: number
  summary: string
}

export function SurgeryCard(
  props: SurgeryCardProps = {
    slug: "appendectomy",
    name: "Appendectomy",
    department: "General Surgery",
    durationHours: 2,
    basePrice: 3500,
    summary: "Removal of the appendix due to inflammation or infection.",
  },
) {
  const { slug, name, department, durationHours, basePrice, summary } = props
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between gap-3">
          <span>{name}</span>
          <Badge variant="secondary" className="bg-emerald-50 text-emerald-800">
            {department}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2 text-sm text-neutral-700">
        <p>{summary}</p>
        <div className="flex flex-wrap items-center gap-4">
          <span className="text-neutral-600">
            Duration: {durationHours} hour{durationHours !== 1 ? "s" : ""}
          </span>
          <span className="font-medium text-neutral-900">Base: {formatCurrency(basePrice)}</span>
        </div>
      </CardContent>
      <CardFooter className="justify-between">
        <div className="flex items-center gap-1 text-xs text-neutral-500">
          <Info className="h-3.5 w-3.5" />
          <span>{"Pricing excludes anesthesia, facility, and room charges unless noted."}</span>
        </div>
        <Button asChild size="sm" className="bg-emerald-600 hover:bg-emerald-700">
          <Link href={`/surgeries/${slug}`}>Details & Pricing</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
